import React from "react";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          Imanma | Direct Response Copywriter
        </h1>
        <p className="text-lg text-gray-700">
          Email & Sales Page Copywriter Who Converts Browsers into Buyers
        </p>
      </header>

      <section className="max-w-4xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">About Me</h2>
        <p className="text-gray-800">
          I'm Imanma, a direct response copywriter who specializes in email, sales letters, and pages across diverse niches. I help businesses turn browsers into buyers with compelling, conversion-driven writing. With a passion for psychology and marketing, I craft messages that speak directly to your ideal customer. Whether you're launching a new product or need to rework your email funnel, I’m here to write copy that delivers results.
        </p>
      </section>

      <section className="max-w-4xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">Services</h2>
        <ul className="list-disc pl-5 text-gray-800 space-y-2">
          <li>Email Copywriting – welcome sequences, product launches, re-engagement</li>
          <li>Sales Pages – persuasive long-form or short-form landing pages</li>
          <li>Sales Letters – compelling letters that drive conversions</li>
        </ul>
      </section>

      <section className="max-w-4xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">Portfolio</h2>
        <ul className="list-disc pl-5 text-gray-800 space-y-2">
          <li>
            <a className="text-blue-600 underline" href="https://docs.google.com/document/d/1bfXoiSNz2Jw5EjElabDvGAq1dj30INTUtbVOMNUlI9o/edit?usp=drivesdk" target="_blank" rel="noopener noreferrer">
              Sales Copy for UCT(Asia) Company – Product marketing strategies
            </a>
          </li>
          <li>Placeholder: Email Launch Copy</li>
          <li>Placeholder: Long-form Sales Page</li>
        </ul>
      </section>

      <section className="max-w-4xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">Testimonial</h2>
        <blockquote className="italic text-gray-600">
          "Working with Imanma was a game-changer. Her copy not only brought clarity but boosted our response rates dramatically. Highly recommended!"
        </blockquote>
      </section>

      <section className="max-w-4xl mx-auto mb-12">
        <h2 className="text-2xl font-semibold mb-4">Contact</h2>
        <p className="text-gray-800">
          📧 Email: <a href="mailto:iimanmachukwu@gmail.com" className="text-blue-600 underline">iimanmachukwu@gmail.com</a><br />
          📸 Instagram: <a href="https://instagram.com/na_tu_regirl" target="_blank" className="text-blue-600 underline">@na_tu_regirl</a>
        </p>
      </section>

      <footer className="text-center text-gray-500 text-sm">
        &copy; {new Date().getFullYear()} Imanma Copywriting Portfolio
      </footer>
    </div>
  );
}
